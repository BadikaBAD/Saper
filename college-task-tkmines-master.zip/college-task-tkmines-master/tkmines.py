import tkinter

from game import Game


def main():
    Game(tkinter.Tk()).run()


if __name__ == "__main__":
    main()
